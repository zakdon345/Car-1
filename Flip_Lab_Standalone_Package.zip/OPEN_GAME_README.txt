HOW TO OPEN FLIP LAB

1. Download Flip_Lab_Standalone_Game.html.
2. Open your Windows Downloads folder.
3. Double-click the HTML file, or right-click > Open with > Google Chrome.
4. Do not use the black preview pane inside ChatGPT; it is only an embedded visualization preview.
5. In the game, press START FLIPPING.
